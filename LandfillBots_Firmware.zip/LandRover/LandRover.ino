/*  =====================================================================
    LandRover.ino  —  BOT 1 of "The Landfill Bots"
    Arduino UNO #1  —  drive + pickup arm + waste classification + sorting
    =====================================================================
    Mechanism summary:
      - 8x TT gear motors (4 per side) via 2x L298N -> skid-steer drive
      - 2 servos position the arm: BASE_SERVO (rotation) + LIFT_SERVO (reach)
      - Gripper is PASSIVE (spring-loaded prongs) - no servo/motor needed to
        grip. It closes automatically as the arm descends onto the waste.
      - The BASE_SERVO angle IS the sorting mechanism: after classifying the
        item, the arm rotates to that bin's fixed angle and lowers onto a
        stripper post, which cams the spring jaws open to release.
      - Requires 3 tabs in the same sketch folder: LandRover.ino, config.h,
        classify.h  (Arduino IDE shows them as tabs automatically).
    ===================================================================== */

#include <Servo.h>
#include <Wire.h>
#include "config.h"
#include "classify.h"

Servo baseServo;
Servo liftServo;

enum State { IDLE, APPROACH, DESCEND_GRAB, LIFT_CLASSIFY, ROTATE_TO_BIN, RELEASE, RETURN_HOME };
State state = IDLE;
unsigned long stateTimer = 0;
uint8_t targetBinAngle = BIN_WET_ANGLE;

void enterState(State s) {
  state = s;
  stateTimer = millis();
}

void setup() {
  Serial.begin(9600);
  Wire.begin();

  baseServo.attach(PIN_BASE_SERVO);
  liftServo.attach(PIN_LIFT_SERVO);
  baseServo.write(BASE_HOME_ANGLE);
  liftServo.write(LIFT_UP_ANGLE);

  pinMode(PIN_IR_SENSOR, INPUT);
  pinMode(PIN_L298N1_IN1, OUTPUT); pinMode(PIN_L298N1_IN2, OUTPUT);
  pinMode(PIN_L298N1_IN3, OUTPUT); pinMode(PIN_L298N1_IN4, OUTPUT);
  pinMode(PIN_L298N2_IN1, OUTPUT); pinMode(PIN_L298N2_IN2, OUTPUT);
  pinMode(PIN_L298N2_IN3, OUTPUT); pinMode(PIN_L298N2_IN4, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);

  classifyInit();      // calibrates/initialises pH, moisture, color sensor
  driveStop();
  Serial.println(F("LandRover ready."));
}

void loop() {
  switch (state) {

    case IDLE:
      driveForward(DRIVE_SPEED_SCAN);
      if (digitalRead(PIN_IR_SENSOR) == IR_TRIGGERED) {
        driveStop();
        enterState(APPROACH);
      }
      break;

    case APPROACH:
      // Brief creep-forward so the target sits under the gripper's reach.
      driveForward(DRIVE_SPEED_APPROACH);
      if (millis() - stateTimer > APPROACH_MS) {
        driveStop();
        enterState(DESCEND_GRAB);
      }
      break;

    case DESCEND_GRAB:
      baseServo.write(BASE_PICKUP_ANGLE);
      liftServo.write(LIFT_DOWN_ANGLE);   // spring gripper slides onto waste here
      if (millis() - stateTimer > DESCEND_MS) {
        enterState(LIFT_CLASSIFY);
      }
      break;

    case LIFT_CLASSIFY:
      liftServo.write(LIFT_UP_ANGLE);
      if (millis() - stateTimer > LIFT_MS) {
        WasteClass c = classifyItem();      // reads moisture + pH + color
        targetBinAngle = binAngleFor(c);
        Serial.print(F("Classified as: "));
        Serial.println(wasteClassName(c));
        enterState(ROTATE_TO_BIN);
      }
      break;

    case ROTATE_TO_BIN:
      baseServo.write(targetBinAngle);
      if (millis() - stateTimer > ROTATE_MS) {
        enterState(RELEASE);
      }
      break;

    case RELEASE:
      // Lower onto the stripper post at this bin - see design notes for the
      // release mechanism; tune RELEASE_DROP_ANGLE on the bench.
      liftServo.write(LIFT_RELEASE_ANGLE);
      if (millis() - stateTimer > RELEASE_MS) {
        liftServo.write(LIFT_UP_ANGLE);
        enterState(RETURN_HOME);
      }
      break;

    case RETURN_HOME:
      baseServo.write(BASE_HOME_ANGLE);
      if (millis() - stateTimer > RETURN_MS) {
        enterState(IDLE);
      }
      break;
  }

  digitalWrite(LED_BUILTIN, state == IDLE ? LOW : HIGH);
}

// ---- Skid-steer drive helpers (both L298N boards wired in parallel per side,
//      ENA/ENB jumpered HIGH on the boards for fixed full-speed operation) ----
void driveForward(int unusedSpeed) {
  digitalWrite(PIN_L298N1_IN1, HIGH); digitalWrite(PIN_L298N1_IN2, LOW);
  digitalWrite(PIN_L298N1_IN3, HIGH); digitalWrite(PIN_L298N1_IN4, LOW);
  digitalWrite(PIN_L298N2_IN1, HIGH); digitalWrite(PIN_L298N2_IN2, LOW);
  digitalWrite(PIN_L298N2_IN3, HIGH); digitalWrite(PIN_L298N2_IN4, LOW);
}

void driveStop() {
  digitalWrite(PIN_L298N1_IN1, LOW); digitalWrite(PIN_L298N1_IN2, LOW);
  digitalWrite(PIN_L298N1_IN3, LOW); digitalWrite(PIN_L298N1_IN4, LOW);
  digitalWrite(PIN_L298N2_IN1, LOW); digitalWrite(PIN_L298N2_IN2, LOW);
  digitalWrite(PIN_L298N2_IN3, LOW); digitalWrite(PIN_L298N2_IN4, LOW);
}
