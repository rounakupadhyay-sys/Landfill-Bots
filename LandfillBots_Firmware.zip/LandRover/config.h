/*  config.h — pin map + tunables for LandRover.ino
    Matches the "ARDUINO WIRING MAPS" diagram in the roadmap PDF.        */
#ifndef CONFIG_H
#define CONFIG_H

// ---- Servos ----
#define PIN_BASE_SERVO   9
#define PIN_LIFT_SERVO   10

// ---- IR waste-detect sensor ----
#define PIN_IR_SENSOR    2
#define IR_TRIGGERED     LOW    // most IR obstacle modules pull LOW on detect - flip if yours is active-HIGH

// ---- Classification sensors ----
#define PIN_MOISTURE     A0     // capacitive moisture sensor, analog
#define PIN_PH           A1     // analog pH sensor board
// Color sensor (TCS34725) uses I2C: SDA=A4, SCL=A5 automatically via Wire.h

// ---- L298N #1 (left-side TT motors, IN1-4 only; ENA/ENB jumpered HIGH on
//      the board itself for fixed full-speed drive - no PWM pins needed) ----
#define PIN_L298N1_IN1   3
#define PIN_L298N1_IN2   4
#define PIN_L298N1_IN3   5
#define PIN_L298N1_IN4   6

// ---- L298N #2 (right-side TT motors) ----
#define PIN_L298N2_IN1   7
#define PIN_L298N2_IN2   8
#define PIN_L298N2_IN3   11
#define PIN_L298N2_IN4   12

// ---- Arm geometry (degrees) - TUNE THESE ON THE BENCH before first run ----
#define BASE_HOME_ANGLE      90   // arm pointing forward, resting
#define BASE_PICKUP_ANGLE    90   // same as home if pickup zone is dead ahead
#define BIN_WET_ANGLE         20
#define BIN_DRY_ANGLE        110
#define BIN_PLASTIC_ANGLE    160

#define LIFT_UP_ANGLE         30   // arm raised, clear of ground/bin walls
#define LIFT_DOWN_ANGLE      150   // arm lowered - gripper slides onto waste
#define LIFT_RELEASE_ANGLE   140   // lowered onto stripper post to pop gripper open

// ---- Timing (ms) - non-blocking, tune to taste ----
#define APPROACH_MS    600
#define DESCEND_MS     700
#define LIFT_MS        500
#define ROTATE_MS      600
#define RELEASE_MS     500
#define RETURN_MS      500

#define DRIVE_SPEED_SCAN      255  // unused with fixed-speed drive, kept for
#define DRIVE_SPEED_APPROACH  255  // future PWM upgrade (see roadmap notes)

#endif
