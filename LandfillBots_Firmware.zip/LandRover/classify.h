/*  classify.h — sensor-fusion waste classification for LandRover.ino

    Why not just pH, as in the original concept sketch?
    A pH probe only produces a meaningful reading on a wet/liquid sample -
    it can't physically tell you "this is plastic" on its own. So the split
    here is:
      1) MOISTURE SENSOR decides wet vs dry (the physically correct test).
      2) pH is read only when wet, as a secondary signal: decomposing
         organic waste trends acidic, which helps confirm true wet/organic
         waste vs. e.g. wet paper.
      3) COLOR / REFLECTANCE SENSOR (checked only when dry) separates
         plastic from dry organic waste - plastics, especially clear or
         light-coloured items, reflect more light back than dull, matte
         organic dry waste.
    This is a heuristic, not a lab-grade material analyser - calibrate the
    three thresholds below against your own waste samples before the demo. */
#ifndef CLASSIFY_H
#define CLASSIFY_H

#include <Adafruit_TCS34725.h>   // Library Manager -> "Adafruit TCS34725"
#include "config.h"

enum WasteClass { WASTE_WET, WASTE_DRY, WASTE_PLASTIC };

Adafruit_TCS34725 tcs = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_50MS, TCS34725_GAIN_4X);

#define MOISTURE_WET_THRESHOLD   550   // 0-1023 — calibrate: dry sample vs. wet sample
#define REFLECTANCE_PLASTIC_MIN  180   // TCS34725 clear-channel — calibrate on the bench

void classifyInit() {
  if (!tcs.begin()) {
    Serial.println(F("WARNING: TCS34725 color sensor not found - check wiring."));
  }
}

int readMoisture() {
  long sum = 0;
  for (int i = 0; i < 8; i++) { sum += analogRead(PIN_MOISTURE); delay(2); }
  return sum / 8;
}

float readPH() {
  int raw = analogRead(PIN_PH);
  float voltage = raw * (5.0 / 1023.0);
  // Replace slope/offset with your own two-point calibration using
  // pH 4.0 and pH 7.0 buffer solutions - see the Testing & Calibration
  // section of the roadmap for the step-by-step procedure.
  return 7.0 - ((voltage - 2.5) / 0.18);
}

uint16_t readReflectance() {
  uint16_t r, g, b, c;
  tcs.getRawData(&r, &g, &b, &c);
  return c;   // clear channel ~ overall brightness/reflectance
}

WasteClass classifyItem() {
  int moisture = readMoisture();

  if (moisture > MOISTURE_WET_THRESHOLD) {
    float ph = readPH();   // logged for reference/tuning, not the deciding vote
    Serial.print(F("moisture=")); Serial.print(moisture);
    Serial.print(F("  pH=")); Serial.println(ph);
    return WASTE_WET;
  }

  uint16_t reflectance = readReflectance();
  Serial.print(F("moisture=")); Serial.print(moisture);
  Serial.print(F("  reflectance=")); Serial.println(reflectance);
  return (reflectance > REFLECTANCE_PLASTIC_MIN) ? WASTE_PLASTIC : WASTE_DRY;
}

uint8_t binAngleFor(WasteClass c) {
  switch (c) {
    case WASTE_WET:     return BIN_WET_ANGLE;
    case WASTE_PLASTIC: return BIN_PLASTIC_ANGLE;
    default:            return BIN_DRY_ANGLE;
  }
}

const char* wasteClassName(WasteClass c) {
  switch (c) {
    case WASTE_WET:     return "WET / ORGANIC";
    case WASTE_PLASTIC: return "PLASTIC";
    default:            return "DRY";
  }
}

#endif
