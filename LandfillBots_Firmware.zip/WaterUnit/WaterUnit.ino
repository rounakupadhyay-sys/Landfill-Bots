/*  =====================================================================
    WaterUnit.ino  —  BOT 2 of "The Landfill Bots"
    Arduino UNO #2  —  standalone water filtration module
    =====================================================================
    Fully independent of LandRover.ino - no wiring or code shared between
    the two boards. Flip the switch, the pump runs and draws water through
    the filter cartridge; flip it off, pump stops. That's the whole job.
    ===================================================================== */

#define PIN_MODE_SWITCH   2     // to GND, uses internal pull-up
#define PIN_PUMP_GATE     9     // to MOSFET gate driving the pump

enum State { STANDBY, PRIME, FILTERING };
State state = STANDBY;
unsigned long stateTimer = 0;

#define PRIME_MS 1500   // short delay after pump-on before we call it "filtering"

void setup() {
  Serial.begin(9600);
  pinMode(PIN_MODE_SWITCH, INPUT_PULLUP);
  pinMode(PIN_PUMP_GATE, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(PIN_PUMP_GATE, LOW);
  Serial.println(F("WaterUnit ready."));
}

void loop() {
  bool switchOn = (digitalRead(PIN_MODE_SWITCH) == LOW);

  switch (state) {
    case STANDBY:
      digitalWrite(PIN_PUMP_GATE, LOW);
      digitalWrite(LED_BUILTIN, LOW);
      if (switchOn) {
        Serial.println(F("Switch ON -> priming pump"));
        digitalWrite(PIN_PUMP_GATE, HIGH);
        stateTimer = millis();
        state = PRIME;
      }
      break;

    case PRIME:
      digitalWrite(LED_BUILTIN, (millis() / 150) % 2);   // fast blink while priming
      if (!switchOn) { state = STANDBY; break; }
      if (millis() - stateTimer > PRIME_MS) {
        Serial.println(F("Filtering"));
        state = FILTERING;
      }
      break;

    case FILTERING:
      digitalWrite(LED_BUILTIN, HIGH);   // steady on while actively filtering
      if (!switchOn) {
        Serial.println(F("Switch OFF -> pump stopped"));
        state = STANDBY;
      }
      break;
  }
}
